<?php
// Path to the JSON file
$tokensPath = 'token.json';
 
// Check if the file exists and load the tokens
if (file_exists($tokensPath)) {
    $jsonContent = file_get_contents($tokensPath);
    $tokens = json_decode($jsonContent, true)['tokens'] ?? [];
} else {
    $tokens = []; // Default to an empty array if the file doesn't exist
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book Borrowing Form</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="container">
    <div class="box header">
      <h1> Book Borrowing System </h1>
      <img src="my image.png" alt="Student ID" class="top-right-image">
    </div>
    <div class="main-content-area">
      <div class="box left-sidebar">
        <h3>Expired Token</h3>
        <ul>
          <?php
          // Load used tokens from used_token.json
          $usedTokensPath = 'used_token.json';
          $usedTokens = file_exists($usedTokensPath) ? json_decode(file_get_contents($usedTokensPath), true)['used_tokens'] ?? [] : [];
          foreach ($usedTokens as $usedToken) {
              echo "<li>" . htmlspecialchars($usedToken) . "</li>";
          }
          ?>
        </ul>
      </div>
      <div class="content-wrapper">
        <div class="box content1"><h3>Today a reader, tomorrow a leader</h3></div>
        
        <div class="box content3">
  <h2>Explore Books</h2>
  <form action="" method="get">
    <label for="search"></label>
    <input type="text" id="search" name="search" required value="<?php if(isset($_GET['search'])) { echo $_GET['search']; } ?>" class="form-control" placeholder="Search by Title or Author">
    <button type="submit" class="btn btn-primary">Search Books</button>
  </form>
  <div class="col-md-1">
    <div class="card mt-4">
      <div class="card-body">
        <table class=class="table table-bordered" style="border: 1px solid black; border-collapse: collapse; width: 100%;">
          <thead>
            <tr>
              <th>ID</th>
              <th>Book Name</th>
              <th>Author Name</th>
              <th>Price</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $con = mysqli_connect("localhost", "root", "", "library");
            if (!$con) {
                die("Connection failed: " . mysqli_connect_error());
            }

            if (isset($_GET['search'])) {
                $filtervalues = mysqli_real_escape_string($con, $_GET['search']);
                $query = "SELECT * FROM books WHERE CONCAT(book_name, author_name, price, quantity) LIKE '%$filtervalues%'";
                $query_run = mysqli_query($con, $query);

                if (!$query_run) {
                    die("Query failed: " . mysqli_error($con));
                }

                if (mysqli_num_rows($query_run) > 0) {
                    foreach ($query_run as $items) {
                        echo "<tr>
                            <td>{$items['id']}</td>
                            <td>{$items['book_name']}</td>
                            <td>{$items['author_name']}</td>
                            <td>{$items['price']}</td>
                            <td>{$items['quantity']}</td>
                          </tr>";
                    }
                } else {
                    echo "<tr><td colspan='5'>No records found</td></tr>";
                }
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

        <div class="box content2">
          <h2> Book Information </h2>
          <form action="add_book.php" method="post" id="bookDetailsForm">
            <label for="book-name">Book Name:</label>
            <input type="text" id="book-name" name="book-name" placeholder="Enter book name" required>
           
            <label for="author-name">Author Name:</label>
            <input type="text" id="author-name" name="author-name" placeholder="Enter author name" required>
 
            <label for="price">Price:</label>
            <input type="number" id="price" name="price" placeholder="Enter price" required>
 
            <label for="quantity">Available Quantity:</label>
            <input type="number" id="quantity" name="quantity" placeholder="Enter available quantity" required>
 
            <label for="isbn">ISBN Number:</label>
            <input type="text" id="isbn" name="isbn" placeholder="Enter ISBN number" required>
 
            <button type="submit">Add Book</button>
          </form>
        </div>
        <div class="small-content">
          <div class="box"></div>
          <div class="box"></div>
          <div class="box"></div>
        </div>
      </div>
      <div class="box right-sidebar">
  <h2>Book List</h2>
  <table style="border: 1px solid black; border-collapse: collapse; width: 100%;">
    <thead>
      <tr>
        <!-- <th style="border: 1px solid black; padding: 8px;">ID</th> -->
        <th style="border: 1px solid black; padding: 8px;">Book Name</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $con = mysqli_connect("localhost", "root", "", "library");
      if (!$con) {
          die("Connection failed: " . mysqli_connect_error());
      }

      $sql = "SELECT book_name FROM books";
      $result = mysqli_query($con, $sql);

      if ($result && mysqli_num_rows($result) > 0) {
          while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>
                      
                      <td style='border: 1px solid black; padding: 8px;'>{$row['book_name']}</td>
                    </tr>";
          }
      } else {
          echo "<tr><td colspan='2' style='border: 1px solid black; padding: 8px; text-align: center;'>No books found</td></tr>";
      }

      mysqli_close($con);
      ?>
    </tbody>
  </table>
</div>

    </div>
    <div class="footer-area">
      <div class="box footer">
        <h2 style="font-size: 14px; text-align: center;">Bibliographic Details</h2>
        <form action="process.php" method="post">
 
          <label for="student-name">Student Full Name:</label>
          <input type="text" id="student-name" name="student-name" required>
         
          <label for="student-id">Student ID:</label>
          <input type="text" id="student-id" name="student-id" required>
         
          <label for="email">Email:</label>
          <input type="email" id="email" name="email" required>
         
          <label for="book-title">Book Title:</label>
          <select id="book-title" name="book-title" required>
          <option value="Lovey: A Very Special Child">Lovey: A Very Special Child</option>
                        <option value="Pother Panchali">Pother Panchali</option>
                        <option value="The House of Special Purpose">The House of Special Purpose</option>
                        <option value="Goin' Someplace Special">Goin' Someplace Special</option>
                        <option value="Krishnakanter Will">Krishnakanter Will</option>
                        <option value="A Cruelty Special to Our Species: Poems">A Cruelty Special to Our Species: Poems</option>
                        <option value="Mishir Ali">Mishir Ali</option>
                        <option value="Her Own Special Island">Her Own Special Island</option>
                        <option value="The Heart Specialist">The Heart Specialist</option>
                        <option value="Sea Stories: My Life in Special Operations">Sea Stories: My Life in Special Operations</option>
          </select>
 
          <label for="borrow-date">Borrow Date:</label>
          <input type="date" id="borrow-date" name="borrow-date" required>
         
          <label for="return-date">Return Date:</label>
          <input type="date" id="return-date" name="return-date" required>
         
          <label for="token">Enter Token:</label>
          <input type="text" id="token" name="token" placeholder="Enter your token">  
         
          <label for="fees">Fees (in TK):</label>
          <input type="number" id="fees" name="fees" required>
         
          <input type="submit" value="Submit">
        </form>
      </div>
      <div class="box footer2">
        <h3>Available Tokens</h3>
        <ul class="scrollable">
          <?php
          if (!empty($tokens)) {
              foreach ($tokens as $token) {
                  echo "<li>" . htmlspecialchars($token) . "</li>";
              }
          } else {
              echo "<li>No tokens available</li>";
          }
          ?>
        </ul>
      </div>
    </div>
  </div>
</body>
</html>
